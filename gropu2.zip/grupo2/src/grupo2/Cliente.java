package grupo2;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;

public class Cliente implements Serializable {
    
    private static final long serialVersionUID = 100L;

    private String nome, endereco, email, cpf;
    private static int cont = lerContador();
    private int id, telefone;
    
    public Cliente(){
        cont++;
        id = cont;
        salvarContador(cont);
    }
    
    public static int getCont() {
        return cont;
    }

    public static void setCont(int aCont) {
        cont = aCont;
    }

 // GETTERS E SETTERS AQUIIIIIIIIIIIIIIIIIIII

    public int getId() {
        return id;
    }
    public String getNome(){
        return nome;
    }
   public void setNome(String nome){
       this.nome=nome;
   }
       public String getEndereco(){
        return endereco;
    }
   public void setEndereco(String endereco){
       this.endereco=endereco;
   }
    public String getEmail(){
        return email;
    }
   public void setEmail(String email){
       this.email=email;
   }
   public int getTelefone(){
        return telefone;
    }
   public void setTelefone(int telefone){
       this.telefone=telefone;
   }
   public String getCpf(){
        return cpf;
    }
   public void setCpf(String cpf){
       this.cpf=cpf;
   }
    public static void salvarContador(int valor) {
        try (FileWriter fw = new FileWriter("src/data/contadorcliente.txt")) {
            fw.write(String.valueOf(valor));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static int lerContador() {
        File arquivo = new File("src/data/contadorcliente.txt");
        if (!arquivo.exists()) {
            return 0;
        }
        try (BufferedReader br = new BufferedReader(new FileReader(arquivo))) {
            return Integer.parseInt(br.readLine());
        } catch (IOException | NumberFormatException e) {
            e.printStackTrace();
            return 0;
        }
    }
    
}