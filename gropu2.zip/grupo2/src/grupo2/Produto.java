package grupo2;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;

public class Produto implements Serializable {
    
    private static final long serialVersionUID = 100L;

    private String nome;
    private double peco, peso, tamanho;
    private static int cont = lerContador();
    private int id, codproduto;
    
    public Produto(){
        cont++;
        id = cont;
        salvarContador(cont);
    }
    
    public static int getCont() {
        return cont;
    }

    public static void setCont(int aCont) {
        cont = aCont;
    }

 // GETTERS E SETTERS AQUIIIIIIIIIIIIIIIIIIII

    public int getId() {
        return id;
    }
    public String getNome() {
        return nome;
    }
    public  void setNome(String nome){
        this.nome=nome;
    }
    public double getPeco() {
        return peco;
    }
    public  void setPeco(double peco){
        this.peco=peco;
    }
    public double getPeso() {
        return peso;
    }
    public  void setPeso(double peso){
        this.peso=peso;
    }
    public double getTamanho() {
        return tamanho;
    }
    public  void setTamanho(double tamanho){
        this.tamanho=tamanho;
    }
    public int getCodProduto() {
        return codproduto;
    }
    public  void setCodProduto(int codproduto){
        this.codproduto=codproduto;
    }
    public static void salvarContador(int valor) {
        try (FileWriter fw = new FileWriter("src/data/contadorproduto.txt")) {
            fw.write(String.valueOf(valor));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static int lerContador() {
        File arquivo = new File("src/data/contadorproduto.txt");
        if (!arquivo.exists()) {
            return 0;
        }
        try (BufferedReader br = new BufferedReader(new FileReader(arquivo))) {
            return Integer.parseInt(br.readLine());
        } catch (IOException | NumberFormatException e) {
            e.printStackTrace();
            return 0;
        }
    }
    
}
