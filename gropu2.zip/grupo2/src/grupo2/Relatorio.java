package grupo2;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;

public class Relatorio implements Serializable {
    
    private static final long serialVersionUID = 100L;

    private String tipo, periodo, conteudo, relatorio;
    private static int cont = lerContador();
    private int id;
    
    public Relatorio(){
        cont++;
        id = cont;
        salvarContador(cont);
    }
    
    public String gerarRelatorio(String tipo, String periodo, String conteudo){
        relatorio = "RELATÓRIO: \nTipo:"+ tipo+ "\n Período:" + periodo + "\n" +  conteudo;
        return relatorio;
    }
    
    public static int getCont() {
        return cont;
    }

    public static void setCont(int aCont) {
        cont = aCont;
    }

 // GETTERS E SETTERS AQUIIIIIIIIIIIIIIIIIIII

    public int getId() {
        return id;
    }
    public String getTipo() {
        return tipo;
    }
    public  void setTipo(String tipo){
        this.tipo=tipo;
    }
    public String getPeriodo() {
        return periodo;
    }
    public  void setPeriodo(String periodo){
        this.periodo=periodo;
    }
    public String getConteudo() {
        return conteudo;
    }
    public  void setConteudo(String conteudo){
        this.conteudo=conteudo;
    }
    public String getRelatorio() {
        return relatorio;
    }
    public  void setRelatorio(String relatorio){
        this.relatorio=relatorio;
    }
    public static void salvarContador(int valor) {
        try (FileWriter fw = new FileWriter("src/data/contadorrelatorio.txt")) {
            fw.write(String.valueOf(valor));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static int lerContador() {
        File arquivo = new File("src/data/contadorrelatorio.txt");
        if (!arquivo.exists()) {
            return 0;
        }
        try (BufferedReader br = new BufferedReader(new FileReader(arquivo))) {
            return Integer.parseInt(br.readLine());
        } catch (IOException | NumberFormatException e) {
            e.printStackTrace();
            return 0;
        }
    }
    
}
