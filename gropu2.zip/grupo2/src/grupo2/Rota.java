package grupo2;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;

public class Rota implements Serializable {
    
    private static final long serialVersionUID = 100L;

    private String inicio, fim;
    private double at3;
    private static int cont = lerContador();
    private int id, distancia, codrota, tempoestimado;
    
    public Rota(){
        cont++;
        id = cont;
        salvarContador(cont);
    }
    
    public static int getCont() {
        return cont;
    }

    public static void setCont(int aCont) {
        cont = aCont;
    }

 // GETTERS E SETTERS AQUIIIIIIIIIIIIIIIIIIII

    public int getId() {
        return id;
    }
    public String getInicio() {
        return inicio;
    }
    public  void setInicio(String inicio){
        this.inicio=inicio;
    }
    public String getFim() {
        return fim;
    }
    public  void setFim(String fim){
        this.fim=fim;
    }
    public double getAt3() {
        return at3;
    }
    public  void setAt3(double at3){
        this.at3=at3;
    }
    public int getDistancia() {
        return distancia;
    }
    public  void setDistancia(int distancia){
        this.distancia=distancia;
    }
    public int getCodRota() {
        return codrota;
    }
    public  void setCodRota(int codrota){
        this.codrota=codrota;
    }
    public int getTempoEstimado() {
        return tempoestimado;
    }
    public  void setTempoEstimado(int tempoestimado){
        this.tempoestimado=tempoestimado;
    }
    public static void salvarContador(int valor) {
        try (FileWriter fw = new FileWriter("src/data/contadorrota.txt")) {
            fw.write(String.valueOf(valor));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static int lerContador() {
        File arquivo = new File("src/data/contadorrota.txt");
        if (!arquivo.exists()) {
            return 0;
        }
        try (BufferedReader br = new BufferedReader(new FileReader(arquivo))) {
            return Integer.parseInt(br.readLine());
        } catch (IOException | NumberFormatException e) {
            e.printStackTrace();
            return 0;
        }
    }
    
}

