package grupo2;

import java.util.*;

public class SistemaLogistica {




    static class Produto {
        String nome;
        String codigo;
        double peso;
        double preco;
        String dimensoes;

        void atualizarPreco(double novoPreco) {
            preco = novoPreco;
            System.out.println("Preço atualizado.");
        }

        void exibirInformacoes() {
            System.out.println("Informações do produto: " + nome);
        }
    }


    static class Pedido {
        int id;
        Cliente cliente;
        List<Produto> listaDeProdutos = new ArrayList<>();
        double valorTotal;
        String status;
        Date dataPedido;

        void calcularTotal() {
            valorTotal = 0;
            for (Produto p : listaDeProdutos) {
                valorTotal += p.preco;
            }
            System.out.println("Total calculado.");
        }

        void alterarStatus(String novoStatus) {
            status = novoStatus;
            System.out.println("Status alterado para: " + status);
        }

        void gerarNotaFiscal() {
            System.out.println("Nota fiscal gerada.");
        }
    }


    static class Veiculo {
        String placa;
        String modelo;
        double capacidade;
        double quilometragem;
        String status;

        void atualizarQuilometragem(double km) {
            quilometragem += km;
            System.out.println("Quilometragem atualizada.");
        }

        boolean verificarDisponibilidade() {
            return "Disponível".equalsIgnoreCase(status);
        }
    }


    static class Motorista {
        String nome;
        String cnh;
        String telefone;
        Veiculo veiculo;

        void atribuirEntrega() {
            System.out.println("Entrega atribuída ao motorista.");
        }

        void registrarSaida() {
            System.out.println("Saída registrada.");
        }

        void registrarChegada() {
            System.out.println("Chegada registrada.");
        }
    }

    static class Rota {
        int id;
        List<String> pontosDeParada = new ArrayList<>();
        double distanciaTotal;
        double tempoEstimado;

        void calcularDistancia() {
            System.out.println("Distância calculada.");
        }

        void otimizarRota() {
            System.out.println("Rota otimizada.");
        }
    }


    static class Entrega {
        int id;
        Pedido pedido;
        Motorista motorista;
        Rota rota;
        String statusEntrega;
        Date dataPrevista;

        void iniciarEntrega() {
            statusEntrega = "Em andamento";
            System.out.println("Entrega iniciada.");
        }

        void finalizarEntrega() {
            statusEntrega = "Finalizada";
            System.out.println("Entrega finalizada.");
        }

        void registrarOcorrencia() {
            System.out.println("Ocorrência registrada.");
        }
    }

    static class Ocorrencia {
        int id;
        Entrega entrega;
        String descricao;
        String tipo;
        Date data;

        void registrar() {
            System.out.println("Ocorrência registrada.");
        }

        void gerarRelatorio() {
            System.out.println("Relatório gerado.");
        }
    }

    static class Pagamento {
        int id;
        Pedido pedido;
        double valor;
        String formaDePagamento;
        String status;

        void processar() {
            status = "Processando";
            System.out.println("Pagamento processando...");
        }

        void confirmarPagamento() {
            status = "Confirmado";
            System.out.println("Pagamento confirmado.");
        }

        void emitirComprovante() {
            System.out.println("Comprovante emitido.");
        }
    }

    static class Relatorio {
        String tipo;
        String periodo;
        String conteudo;

        void gerarRelatorioEntregas() {
            System.out.println("Relatório de entregas gerado.");
        }

        void gerarRelatorioMotoristas() {
            System.out.println("Relatório de motoristas gerado.");
        }

        void gerarRelatorioFinanceiro() {
            System.out.println("Relatório financeiro gerado.");
        }
    }


    // ======== MENU PRINCIPAL ========
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int opcao;

        do {
            System.out.println("\n===== SISTEMA DE LOGÍSTICA =====");
            System.out.println("1. Cadastrar Cliente");
            System.out.println("2. Criar Pedido");
            System.out.println("3. Registrar Entrega");
            System.out.println("4. Gerar Relatórios");
            System.out.println("0. Sair");
            System.out.print("Escolha: ");
            opcao = sc.nextInt();

            switch (opcao) {
                case 1:
                    System.out.println(">> Cadastro de Cliente");
                    Cliente c = new Cliente();
                    break;

                case 2:
                    System.out.println(">> Criando Pedido");
                    Pedido p = new Pedido();
                    p.calcularTotal();
                    break;

                case 3:
                    System.out.println(">> Registrando Entrega");
                    Entrega e = new Entrega();
                    e.iniciarEntrega();
                    break;

                case 4:
                    System.out.println(">> Relatórios");
                    Relatorio r = new Relatorio();
                    r.gerarRelatorioEntregas();
                    break;

                case 0:
                    System.out.println("Encerrando...");
                    break;

                default:
                    System.out.println("Opção inválida.");
            }

        } while (opcao != 0);

        sc.close();
    }
}