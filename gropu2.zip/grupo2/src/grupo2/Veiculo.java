package grupo2;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;

public class Veiculo implements Serializable {
    
    private static final long serialVersionUID = 100L;

    private String modelo, status, placa;
    private double capacidade;
    private static int cont = lerContador();
    private int id, quilometragem;
    
    public Veiculo(){
        cont++;
        id = cont;
        salvarContador(cont);
    }
    
    public static int getCont() {
        return cont;
    }

    public static void setCont(int aCont) {
        cont = aCont;
    }

 // GETTERS E SETTERS AQUIIIIIIIIIIIIIIIIIIII

    public int getId() {
        return id;
    }
    public String getModelo() {
        return modelo;
    }
    public  void setModelo(String modelo){
        this.modelo=modelo;
    }
    public String getStatus() {
        return status;
    }
    public  void setStatus(String status){
        this.status=status;
    }
    public double getCapacidade() {
        return capacidade;
    }
    public  void setCapacidade(double capacidade){
        this.capacidade=capacidade;
    }
    public String getPlaca() {
        return placa;
    }
    public  void setPlaca(String placa){
        this.placa=placa;
    }
    public int getQuilometragem() {
        return quilometragem;
    }
    public  void setQuilometragem(int quilometragem){
        this.quilometragem=quilometragem;
    }
    
    public static void salvarContador(int valor) {
        try (FileWriter fw = new FileWriter("src/data/contadorveiculo.txt")) {
            fw.write(String.valueOf(valor));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static int lerContador() {
        File arquivo = new File("src/data/contadorveiculo.txt");
        if (!arquivo.exists()) {
            return 0;
        }
        try (BufferedReader br = new BufferedReader(new FileReader(arquivo))) {
            return Integer.parseInt(br.readLine());
        } catch (IOException | NumberFormatException e) {
            e.printStackTrace();
            return 0;
        }
    }
    
}
