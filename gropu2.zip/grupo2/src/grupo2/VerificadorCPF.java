package grupo2;
import java.util.InputMismatchException;
public class VerificadorCPF {
      public static boolean eCPF(String cpf){
        if ((cpf.equals("00000000000"))||(cpf.equals("11111111111"))||(cpf.equals("22222222222"))||(cpf.equals("33333333333"))
                ||(cpf.equals("44444444444"))||
            (cpf.equals("55555555555"))||(cpf.equals("66666666666"))||(cpf.equals("77777777777"))||
            (cpf.equals("88888888888"))||(cpf.equals("99999999999"))||(cpf.length()!=11)){
            return(false);
        }
        try{
            char dv10, dv11;
            int soma = 0;
            int peso = 10;
            for(int i=0; i<9; i++){
                int numero = (int) (cpf.charAt(i)-48);
                soma = soma + (numero*peso);
                peso--;
            }
            int resto = 11 - (soma%11);
            if((resto == 10) || (resto == 11)){
                dv10 = '0';
        }else{
                dv10 = (char)(resto + 48);
            }
            soma = 0;
            peso = 11;
            for(int i=0; i<10; i++){
                int numero = (int) (cpf.charAt(i)-48);
                soma = soma + (numero*peso);
                peso--;
            }
            resto = 11 - (soma%11);
            if((resto == 10) || (resto == 11)){
                dv11 = '0';
        }else{
                dv11 = (char)(resto + 48);
            }
             if ((dv10 == cpf.charAt(9)) && (dv11 == cpf.charAt(10)))
                 return(true);
            else return(false);
        }catch (InputMismatchException error) {
            return(false);
        }
    }
}

