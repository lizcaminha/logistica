package grupo2;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;

public class Entrega implements Serializable {
    
    private static final long serialVersionUID = 100L;

    private String rota, status, cpf, data;
    private static int cont = lerContador();
    private int id, codpedido;
    
    public Entrega(){
        cont++;
        id = cont;
        salvarContador(cont);
    }
    
    public static int getCont() {
        return cont;
    }

    public static void setCont(int aCont) {
        cont = aCont;
    }

 // GETTERS E SETTERS AQUIIIIIIIIIIIIIIIIIIII

    public int getId() {
        return id;
    }
    public String getRota() {
        return rota;
    }
    public  void setRota(String rota ){
        this.rota=rota;
    }
    public String getStatus() {
        return status;
    }
    public  void setStatus(String status){
        this.status=status;
    }
    public String getData() {
        return data;
    }
    public  void setData(String data){
        this.data=data;
    }
    public int getCodPedido() {
        return codpedido;
    }
    public  void setId(int codpedido){
        this.codpedido=codpedido;
    }
    public String getCpf() {
        return cpf;
    }
    public  void setCpf(String cpf){
        this.cpf=cpf;
    }
    public static void salvarContador(int valor) {
        try (FileWriter fw = new FileWriter("src/data/contadorentrega.txt")) {
            fw.write(String.valueOf(valor));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static int lerContador() {
        File arquivo = new File("src/data/contadorentrega.txt");
        if (!arquivo.exists()) {
            return 0;
        }
        try (BufferedReader br = new BufferedReader(new FileReader(arquivo))) {
            return Integer.parseInt(br.readLine());
        } catch (IOException | NumberFormatException e) {
            e.printStackTrace();
            return 0;
        }
    }
    
}
