package grupo2;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;

public class Motorista implements Serializable {
    
    private static final long serialVersionUID = 100L;

    private String nome;
    private static int cont = lerContador();
    private int id, placa, cnh, telefone;
    
    public Motorista(){
        cont++;
        id = cont;
        salvarContador(cont);
    }
    
    public static int getCont() {
        return cont;
    }

    public static void setCont(int aCont) {
        cont = aCont;
    }

 // GETTERS E SETTERS AQUIIIIIIIIIIIIIIIIIIII

    public int getId() {
        return id;
    }
    public  void setId(int id){
        this.id=id;
    }
    public String getNome() {
        return nome;
    }
    public  void setNome(String nome){
        this.nome=nome;
    }
    public int getPlaca() {
        return placa;
    }
    public  void setPlaca(int placa){
        this.placa=placa;
    }
    public int getCnh() {
        return cnh;
    }
    public  void setCnh(int cnh){
        this.cnh=cnh;
    }
    public int getTelefone() {
        return telefone;
    }
    public  void setTelefone(int telefone){
        this.telefone=telefone;
    }
    public static void salvarContador(int valor) {
        try (FileWriter fw = new FileWriter("src/data/contadormotorista.txt")) {
            fw.write(String.valueOf(valor));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static int lerContador() {
        File arquivo = new File("src/data/contadormotorista.txt");
        if (!arquivo.exists()) {
            return 0;
        }
        try (BufferedReader br = new BufferedReader(new FileReader(arquivo))) {
            return Integer.parseInt(br.readLine());
        } catch (IOException | NumberFormatException e) {
            e.printStackTrace();
            return 0;
        }
    }
    
}
