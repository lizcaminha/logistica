package grupo2;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;

public class Ocorrencia implements Serializable {
    
    private static final long serialVersionUID = 100L;

    private String desc, tipo, data;
    private static int cont = lerContador();
    private int id, codocorrencia;
    
    public Ocorrencia(){
        cont++;
        id = cont;
        salvarContador(cont);
    }
    
    public static int getCont() {
        return cont;
    }

    public static void setCont(int aCont) {
        cont = aCont;
    }

 // GETTERS E SETTERS AQUIIIIIIIIIIIIIIIIIIII

    public int getId() {
        return id;
    }
    public String getDesc() {
        return desc;
    }
    public  void setDesc(String desc){
        this.desc=desc;
    }
    public String getTipo() {
        return tipo;
    }
    public  void setTipo(String tipo){
        this.tipo=tipo;
    }
    public int getCodOcorrencia() {
        return codocorrencia;
    }
    public  void setCodOcorrencia(int codocorrencia){
        this.codocorrencia=codocorrencia;
    }
    public String getData() {
        return data;
    }
    public  void setData(String data){
        this.data=data;
    }
    public static void salvarContador(int valor) {
        try (FileWriter fw = new FileWriter("src/data/contadorocorrencia.txt")) {
            fw.write(String.valueOf(valor));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static int lerContador() {
        File arquivo = new File("src/data/contadorocorrencia.txt");
        if (!arquivo.exists()) {
            return 0;
        }
        try (BufferedReader br = new BufferedReader(new FileReader(arquivo))) {
            return Integer.parseInt(br.readLine());
        } catch (IOException | NumberFormatException e) {
            e.printStackTrace();
            return 0;
        }
    }
    
}
