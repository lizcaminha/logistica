package grupo2;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;

public class Pagamento implements Serializable {
    
    private static final long serialVersionUID = 100L;

    private String formadepagamento, status;
    private double at3;
    private static int cont = lerContador();
    private int id, codpedido, valor;
    
    public Pagamento(){
        cont++;
        id = cont;
        salvarContador(cont);
    }
    
    public static int getCont() {
        return cont;
    }

    public static void setCont(int aCont) {
        cont = aCont;
    }

 // GETTERS E SETTERS AQUIIIIIIIIIIIIIIIIIIII

    public int getId() {
        return id;
    }
    public String getFormaDePagamento() {
        return formadepagamento;
    }
    public  void setFormaDePagamento(String formadepagamento){
        this.formadepagamento=formadepagamento;
    }
    public String getStatus() {
        return status;
    }
    public  void setStatus(String status){
        this.status=status;
    }
    public int getCodPedido() {
        return codpedido;
    }
    public  void setCodPedido(int codpedido){
        this.codpedido=codpedido;
    }
    public int getValor() {
        return valor;
    }
    public  void setValor(int valor){
        this.valor=valor;
    }
    public static void salvarContador(int valor) {
        try (FileWriter fw = new FileWriter("src/data/contadorpagamento.txt")) {
            fw.write(String.valueOf(valor));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static int lerContador() {
        File arquivo = new File("src/data/contadorpagamento.txt");
        if (!arquivo.exists()) {
            return 0;
        }
        try (BufferedReader br = new BufferedReader(new FileReader(arquivo))) {
            return Integer.parseInt(br.readLine());
        } catch (IOException | NumberFormatException e) {
            e.printStackTrace();
            return 0;
        }
    }
    
}
