package grupo2;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;

public class Pedido implements Serializable {
    
    private static final long serialVersionUID = 100L;

    private String codpedido, cpf, produto, status, data;
    private double valor;
    private static int cont = lerContador();
    private int id;
    
    public Pedido(){
        cont++;
        id = cont;
        salvarContador(cont);
    }
    
    public static int getCont() {
        return cont;
    }

    public static void setCont(int aCont) {
        cont = aCont;
    }

 // GETTERS E SETTERS AQUIIIIIIIIIIIIIIIIIIII

    public int getId() {
        return id;
    }
    public String getCodPedido() {
        return codpedido;
    }
    public  void setCodPedido(String codpedido){
        this.codpedido=codpedido;
    }
    public String getCpf() {
        return cpf;
    }
    public  void setCpf(String cpf){
        this.cpf=cpf;
    }
    public String getProduto() {
        return produto;
    }
    public  void setProduto(String produto){
        this.produto=produto;
    }
    public String getStatus() {
        return status;
    }
    public  void setStatus(String status){
        this.status=status;
    }
    public double getValor() {
        return valor;
    }
    public  void setValor(double valor){
        this.valor=valor;
    }
    
    public String getData() {
        return data;
    }
    public  void setData(String data){
        this.data=data;
    }
    public static void salvarContador(int valor) {
        try (FileWriter fw = new FileWriter("src/data/contadorpedido.txt")) {
            fw.write(String.valueOf(valor));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static int lerContador() {
        File arquivo = new File("src/data/contadorpedido.txt");
        if (!arquivo.exists()) {
            return 0;
        }
        try (BufferedReader br = new BufferedReader(new FileReader(arquivo))) {
            return Integer.parseInt(br.readLine());
        } catch (IOException | NumberFormatException e) {
            e.printStackTrace();
            return 0;
        }
    }
    
}